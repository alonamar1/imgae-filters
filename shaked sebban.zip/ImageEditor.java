
// ImageEditor.java
import java.awt.image.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.io.File;
import org.json.*;

public class ImageEditor {
    private BufferedImage image;
    private Config config;

    public ImageEditor(Config config) throws Exception {
        this.config = config;


        if (!config.isDisplay() && config.getOutputPath() == null) {
            throw new IllegalArgumentException("Config must include either 'output' path or 'display' set to true.");
        }

        //load the image from the input path
        this.image = ImageIO.read(new File(config.getInputPath()));
    }

    public void applyOperations() {
        
        //get the operations from the config
        JSONArray ops = config.getOperations();
        for (int i = 0; i < ops.length(); i++) 
        {
            JSONObject op = ops.getJSONObject(i); //create a JSONObject for each operation

           //get the type field
            String type = op.getString("type");

            //get the parameters for the filter
            JSONObject params = new JSONObject(op.toString());

            //remove the type field from the parameters
            params.remove("type");

            Filter filter = getFilterByName(type);
            if (filter != null) {
                image = filter.apply(image, params);
            } else {
                System.out.println("Unknown filter: " + type);
            }
        }
    }

    private Filter getFilterByName(String type) {
        switch (type.toLowerCase()) {
            case "box":
                return new BoxBlurFilter();
            case "brightness":
                return new BrightnessAdjustment();
            case "contrast":
                return new ContrastAdjustment();

            case "saturation":
                return new SaturationAdjustment();

            case "sharpen":
                return new SharpenFilter();

            /*case "sobel":
                //TODO: implement Sobel filter
                */
            default:
                return null;
        }
    }

    public void saveImage(String outputPath) throws Exception {
        String format = "png"; //default format

        //assuming the output path is a valid file name with format  
        if (outputPath.contains(".")) {
            int dotIndex = outputPath.lastIndexOf(".");
            format = outputPath.substring(dotIndex + 1).toLowerCase();
        }
    
        //save the image to the output path with the right format
        ImageIO.write(image, format, new File(outputPath));
    }

}
